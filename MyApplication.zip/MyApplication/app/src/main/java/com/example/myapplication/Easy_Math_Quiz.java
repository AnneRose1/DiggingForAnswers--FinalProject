package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Easy_Math_Quiz extends AppCompatActivity {
    private MathQuestionLibrary mathQuestionLibrary = new MathQuestionLibrary();

    private TextView mathQuestionsView;
    private Button mathAnswer1;
    private Button mathAnswer2;
    private Button mathAnswer3;
    private Button mathAnswer4;
    private String mathCorrectAnswers;
    private int mathQuestionNumber = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easy__math__quiz);

        mathQuestionsView = findViewById(R.id.Questions);
        mathAnswer1 = findViewById(R.id.answer_math1);
        mathAnswer2 = findViewById(R.id.answer_math2);
        mathAnswer3 = findViewById(R.id.answer_math3);
        mathAnswer4 = findViewById(R.id.answer_math4);

        updateQuestion();

        //button controls
        mathAnswer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mathAnswer1.getText() == mathCorrectAnswers){
                    updateQuestion();
                    Toast.makeText(Easy_Math_Quiz.this, "correct", Toast.LENGTH_SHORT).show();
                }else{
                    updateQuestion();
                    Toast.makeText(Easy_Math_Quiz.this, "wrong", Toast.LENGTH_SHORT).show();
                }

            }
        });
        mathAnswer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mathAnswer2.getText() == mathCorrectAnswers){
                    updateQuestion();
                    Toast.makeText(Easy_Math_Quiz.this, "correct", Toast.LENGTH_SHORT).show();
                }else{
                    updateQuestion();
                    Toast.makeText(Easy_Math_Quiz.this, "wrong", Toast.LENGTH_SHORT).show();
                }

            }
        });
        mathAnswer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mathAnswer3.getText() == mathCorrectAnswers){
                    updateQuestion();
                    Toast.makeText(Easy_Math_Quiz.this, "correct", Toast.LENGTH_SHORT).show();
                }else{
                    updateQuestion();
                    Toast.makeText(Easy_Math_Quiz.this, "wrong", Toast.LENGTH_SHORT).show();
                }

            }
        });
        mathAnswer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mathAnswer4.getText() == mathCorrectAnswers){
                    updateQuestion();
                    Toast.makeText(Easy_Math_Quiz.this, "correct", Toast.LENGTH_SHORT).show();
                }else{
                    updateQuestion();
                    Toast.makeText(Easy_Math_Quiz.this, "wrong", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
    private void updateQuestion(){
        mathQuestionsView.setText(mathQuestionLibrary.getQuestionMath(mathQuestionNumber));
        mathAnswer1.setText(mathQuestionLibrary.getCorrectAnswerMath(mathQuestionNumber));
        mathAnswer2.setText(mathQuestionLibrary.getCorrectAnswerMath(mathQuestionNumber));
        mathAnswer3.setText(mathQuestionLibrary.getCorrectAnswerMath(mathQuestionNumber));
        mathAnswer4.setText(mathQuestionLibrary.getCorrectAnswerMath(mathQuestionNumber));

        mathCorrectAnswers = mathQuestionLibrary.getCorrectAnswerMath(mathQuestionNumber);
        mathQuestionNumber++;
    }
}
