package com.example.myapplication;

public class MathQuestionLibrary extends Easy_Math_Quiz{
    private String[] mathQuestions = {
        "What is 2 + 2 equal to?",
        "How many sides does a triangle have?",
        "What is the answer to 2+2*5-10^2?",
        "If the side of a right triangle are 3 inches and 4 inches, what is the hypotenuse of this right triangle?",
        "What is log base 10 of 100?",
        "What is the log base  5 of 125?"
    };
    private String[][] mathChoices= {
            {"4","22","0","2"},
            {"4","2","3","5"},
            {"88","80","-88","100"},
            {"5","4.5","6","3"},
            {"3","4","1","2"},
            {"1","3","6","2"}
    };
    private String[] mathCorrectAnswers = {"4","3","-88","5","2","3"};
    public String getQuestionMath (int a){
        String question0 = mathQuestions[a];
        return question0;
    }
    public String getChoicesMath0 (int a){
        String choice0 = mathChoices[a][0];
        return choice0;
    }
    public String getChoicesMath1 (int a){
        String choice1 = mathChoices[a][1];
        return choice1;
    }
    public String getChoicesMath2 (int a){
        String choice2 = mathChoices[a][2];
        return choice2;
    }
    public String getChoicesMath3 (int a){
        String choice3 = mathChoices[a][3];
        return choice3;
    }
    public String getCorrectAnswerMath(int a) {
        String answerMath = mathCorrectAnswers[a];
        return answerMath;
    }
}
