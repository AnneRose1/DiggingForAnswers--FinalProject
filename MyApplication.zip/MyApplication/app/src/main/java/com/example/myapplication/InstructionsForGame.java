package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class InstructionsForGame extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions_for_game);

        goToMathQuiz();
    }
    private void goToMathQuiz(){
        Button nextPage = (Button) findViewById(R.id.start_screen_begin_2);
        nextPage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                startActivity(new Intent(InstructionsForGame.this, Easy_Math_Quiz.class));
            }
        });
    }

}
